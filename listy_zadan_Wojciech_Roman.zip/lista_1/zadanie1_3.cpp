#include <iostream>
using namespace std;
int main()
{
cout<<"\x1b[41m Cześć! \x1b[0m"<<endl;
cout<<"\x1b[42m Cześć! \x1b[0m"<<endl;
cout<<"\x1b[43m Cześć! \x1b[0m"<<endl;
return 0;
}
