#include <iostream>
using namespace std;
int main()
{
	cout<<"\x1b[31mW\x1b[32mo\x1b[33mj\x1b[34mt\x1b[35me\x1b[36mk \x1b[37mR\x1b[90mo\x1b[91mm\x1b[92ma\x1b[93mn\x1b[0m"<<endl;
	return 0;
}
