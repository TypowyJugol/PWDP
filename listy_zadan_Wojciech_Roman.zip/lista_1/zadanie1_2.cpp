#include <iostream>
using namespace std;
int main()
{
	cout<<"Witaj Wotek"<<endl;
	return 0;
}
