#include <iostream>
using namespace std;
int main()
{
	int i=1;
	while(i<=100)
	{
	cout<<"Hello world"<<endl;
	i++;
	}
	return 0;
}
