#include <iostream>
using namespace std;
int main()
{
	int x,y;
	for(y=-5;y<=5;y++)
	{
	for(x=-5;x<=5;x++)
	{
	cout<<x*y;
	cout<<"	";
	}
	cout<<endl;
	}
	return 0;
}
