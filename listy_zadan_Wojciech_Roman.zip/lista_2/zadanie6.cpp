#include <iostream>
using namespace std;
int main()
{
	cout<<"\x1b[43m         \x1b[44m             \x1b[43m                                                                   \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m             \x1b[43m                                                                   \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m   \x1b[43m                                                                             \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m   \x1b[43m                            \x1b[44m  \x1b[43m                           \x1b[44m  \x1b[43m                  \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m   \x1b[43m                            \x1b[44m  \x1b[43m                           \x1b[44m  \x1b[43m                  \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m   \x1b[43m                            \x1b[44m  \x1b[43m                           \x1b[44m  \x1b[43m                  \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m   \x1b[43m                            \x1b[44m  \x1b[43m                           \x1b[44m  \x1b[43m                  \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m   \x1b[43m                   \x1b[44m                    \x1b[43m         \x1b[44m                    \x1b[43m         \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m   \x1b[43m                   \x1b[44m                    \x1b[43m         \x1b[44m                    \x1b[43m         \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m   \x1b[43m                            \x1b[44m  \x1b[43m                           \x1b[44m  \x1b[43m                  \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m   \x1b[43m                            \x1b[44m  \x1b[43m                           \x1b[44m  \x1b[43m                  \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m   \x1b[43m                            \x1b[44m  \x1b[43m                           \x1b[44m  \x1b[43m                  \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m   \x1b[43m                            \x1b[44m  \x1b[43m                           \x1b[44m  \x1b[43m                  \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m             \x1b[43m                                                                   \x1b[0m"<<endl;
	cout<<"\x1b[43m         \x1b[44m             \x1b[43m                                                                   \x1b[0m"<<endl;
	return 0;
}
